configs.onChange(data => {
    if(!data) return;
    const { panels } = data;
    $("#players_left #main_primary").text(panels.left_title)
    $("#players_left #main_secondary").text(panels.left_subtitle)
    
    $("#players_right #main_primary").text(panels.right_title)
    $("#players_right #main_secondary").text(panels.right_subtitle)
    
    $("#players_left #box_image").attr("src", `data:image/png;base64,${panels.left_image}`)
    $("#players_right #box_image").attr("src", `data:image/png;base64,${panels.right_image}`)
});
actions.on("toggleAvatars", () => {
    console.log("Avatars toggled");
})